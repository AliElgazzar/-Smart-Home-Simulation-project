#ifndef GIE_PRIVATE_H_
#define GIE_PRIVATE_H_
/* global interrupt register*/
#define SREG *((u8*)0x5F)
#endif /* GIE_PRIVATE_H_ */
