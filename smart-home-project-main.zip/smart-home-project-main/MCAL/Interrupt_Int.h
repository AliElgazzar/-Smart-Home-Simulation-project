/*
 * Interrupt.h
 *
 *  Created on: Dec 3, 2021
 *      Author: techno
 */

#ifndef SMART_HOME_MCAL_INTERRUPT_INT_H_
#define SMART_HOME_MCAL_INTERRUPT_INT_H_
#include "stdTypes.h"

void Call_Back_Fun(void (*ptf)(void));

#endif /* SMART_HOME_MCAL_INTERRUPT_INT_H_ */
