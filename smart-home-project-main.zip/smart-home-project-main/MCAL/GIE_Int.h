#ifndef GIE_INT_H_
#define GIE_INT_H_

void GIE_Enable();
void GIE_Disable();

#endif /* GIE_INT_H_ */
