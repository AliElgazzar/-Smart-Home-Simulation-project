/*
 * USART_Config.h
 *
 *  Created on: Oct 26, 2021
 *      Author: Abdelrahman Mahmoud
 */
/*MODES OPTOINS*/
/*USART Mode Select*/
#define Synch  0
#define Asynch_Noraml_Mode 1
#define Asynch_Double_Speed_Mode 2
/*parity mode*/
#define DISABLE 0
#define ODD     1
#define EVEN    2
