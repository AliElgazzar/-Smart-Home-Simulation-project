/*
 * Air_Con_int.c
 *
 *  Created on: Nov 29, 2021
 *      Author: Ali
 */

#ifndef SMART_HOME_APP_AIR_CON_INTI_C_
#define SMART_HOME_APP_AIR_CON_INTI_C_

void  AC_On();
void  AC_Off();
void AC_Init();

#endif /* SMART_HOME_APP_AIR_CON_INTI_C_ */
