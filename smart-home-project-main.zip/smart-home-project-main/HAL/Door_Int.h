/*
 * Door_Int.h
 *
 *  Created on: Nov 29, 2021
 *      Author: Loai
 */

#ifndef SMART_HOME_APP_DOOR_INT_H_
#define SMART_HOME_APP_DOOR_INT_H_
#define DOOR_OPEN  1
#define DOOR_CLOSE 0
void Door_Open();
void Door_Close();
void Door_Ini();


#endif /* SMART_HOME_APP_DOOR_INT_H_ */
